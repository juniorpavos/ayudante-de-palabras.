package com.ayudante.palabras

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var box: LinearLayout
    private lateinit var out: TextView
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var last: Bitmap? = null
    @Volatile private var words: List<String> = emptyList()
    @Volatile private var common: Set<String> = emptySet()

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("c", "Ayudante", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "c").setContentTitle("Ayudante de palabras activo")
            .setSmallIcon(android.R.drawable.ic_menu_search).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = i?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        proj = getSystemService(MediaProjectionManager::class.java)
            .getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() {}, Handler(Looper.getMainLooper()))
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        proj!!.createVirtualDisplay("cap", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        Thread {
            words = assets.open("words.txt").bufferedReader().useLines { s ->
                s.map { it.trim().uppercase() }.filter { it.length in 3..10 }.toList()
            }
            common = assets.open("common.txt").bufferedReader().readLines().map { it.trim().uppercase() }.toSet()
        }.start()
        showOverlay()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WindowManager::class.java)
        val btn = Button(this).apply {
            text = "✨ PALABRA"
            setOnClickListener { scan() }
            setOnLongClickListener { stopSelf(); true }
        }
        out = TextView(this).apply {
            setTextColor(Color.WHITE); setBackgroundColor(0xCC000000.toInt())
            textSize = 20f; setPadding(24, 12, 24, 12)
        }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(btn); addView(out) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 250 }
        wm.addView(box, lp)
    }

    // Recorta la rueda de letras (zona fija abajo en el centro)
    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            val p = img.planes[0]
            val full = Bitmap.createBitmap(p.rowStride / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            val w = img.width; val h = img.height
            img.close()
            last = Bitmap.createBitmap(full, (w * 0.22).toInt(), (h * 0.59).toInt(), (w * 0.60).toInt(), (h * 0.30).toInt())
        }
        return last
    }

    private fun scan() {
        out.text = "Leyendo…"
        val bmp = grab() ?: run { out.text = "Tocá de nuevo"; return }
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                val letters = r.text.uppercase().filter { it in 'A'..'Z' }
                out.text = when {
                    letters.length < 3 -> "No veo letras"
                    words.isEmpty() -> "Cargando diccionario…"
                    else -> {
                        val found = find(letters).take(5)
                        letters + "\n" + (if (found.isEmpty()) "Sin resultados" else found.joinToString("\n"))
                    }
                }
            }
            .addOnFailureListener { out.text = "Error al leer" }
    }

    private fun find(l: String): List<String> {
        val c = IntArray(26); l.forEach { c[it - 'A']++ }
        return words.filter { w ->
            if (w.length > l.length) return@filter false
            val u = IntArray(26)
            for (ch in w) { if (++u[ch - 'A'] > c[ch - 'A']) return@filter false }
            true
        }.sortedWith(compareByDescending<String> { it.length }.thenByDescending { it in common })
    }

    override fun onDestroy() {
        runCatching { wm.removeView(box) }
        proj?.stop()
        super.onDestroy()
    }
}
